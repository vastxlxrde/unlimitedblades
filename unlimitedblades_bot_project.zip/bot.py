import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes

BOT_TOKEN = os.getenv('BOT_TOKEN')
ADMIN_CHAT_ID = 1874218277  # Ваш ID чата, куда приходят демки

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("📤 Отправить демо", callback_data="send_demo")],
        [InlineKeyboardButton("📩 Обратная связь", callback_data="support")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        "🎵 Добро пожаловать в официальный бот музыкального лейбла unlimitedblades 🎵\n\n"
        "Тут ты найдёшь всё, что нужно: отправка демо, обратная связь и многое другое.\n\n"
        "📌 Используй команды ниже, чтобы быстро найти то, что тебе нужно: отправка демо, обратная связь и многое другое.\n\n"
        "🔹 /senddemo — отправка демо\n"
        "🔹 /feedback — связаться с нами\n\n"
        "Если есть звук — не держи в себе. Закидывай, мы слушаем. 🎧\n\n"
        "____________________________________________________________________\n\n"
        "🎵 Welcome to the official unlimitedblades music label bot 🎵\n\n"
        "Here you'll find everything you need: demo submission, feedback, and much more.\n\n"
        "📌 Use the commands below to quickly find what you need: demo submission, feedback, and much more.\n\n"
        "If you've got sound - don't keep it to yourself. Send it, we're listening\n\n"
        "🔹 /senddemo — send demo\n"
        "🔹 /feedback — contact us",
        reply_markup=reply_markup
    )

async def send_demo_instruction(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Отправь мне свой трек в формате mp3 или wav файла! 🎵\n\nSend me your track in mp3 or wav format! 🎵")

async def handle_demo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    message = update.message
    user = message.from_user
    file = message.audio or message.voice or message.document

    if not file:
        await message.reply_text("Пожалуйста, отправь аудио файл, голосовое или документ с треком.")
        return

    keyboard = [
        [
            InlineKeyboardButton("✅ Принять", callback_data=f"accept_{user.id}"),
            InlineKeyboardButton("❌ Отклонить", callback_data=f"reject_{user.id}")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    caption = f"🎶 Новая демка от @{user.username or user.first_name} (ID: {user.id})"

    try:
        if message.audio:
            await context.bot.send_audio(
                chat_id=ADMIN_CHAT_ID,
                audio=file.file_id,
                caption=caption,
                reply_markup=reply_markup
            )
        elif message.voice:
            await context.bot.send_voice(
                chat_id=ADMIN_CHAT_ID,
                voice=file.file_id,
                caption=caption,
                reply_markup=reply_markup
            )
        elif message.document:
            await context.bot.send_document(
                chat_id=ADMIN_CHAT_ID,
                document=file.file_id,
                caption=caption,
                reply_markup=reply_markup
            )

        await message.reply_text("Спасибо! Твоя демка отправлена лейблу. 🔥")
    except Exception as e:
        await message.reply_text("Произошла ошибка при отправке демки. Попробуй ещё раз позже.")
        print(f"Ошибка при отправке демки: {e}")

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if query.data == "send_demo":
        keyboard = [[InlineKeyboardButton("◀️ Назад", callback_data="back")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.message.edit_text("Отправь мне свой трек в формате mp3 или wav файла! 🎵\n\nSend me your track in mp3 or wav format! 🎵", reply_markup=reply_markup)
    elif query.data == "support":
        keyboard = [[InlineKeyboardButton("◀️ Назад", callback_data="back")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.message.edit_text("📩 Для связи с поддержкой пишите: @unlimitedbladees\n\n📩 For support, please contact: @unlimitedbladees", reply_markup=reply_markup)
    elif query.data == "back":
        keyboard = [
            [InlineKeyboardButton("📤 Отправить демо", callback_data="send_demo")],
            [InlineKeyboardButton("📩 Обратная связь", callback_data="support")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.message.edit_text(
            "🎵 Добро пожаловать в официальный бот музыкального лейбла unlimitedblades 🎵\n\n"
            "Тут ты найдёшь всё, что нужно: отправка демо, обратная связь и многое другое.\n\n"
            "📌 Используй команды ниже, чтобы быстро найти то, что тебе нужно: отправка демо, обратная связь и многое другое.\n\n"
            "🔹 /senddemo — отправка демо\n"
            "🔹 /feedback — связаться с нами\n\n"
            "Если есть звук — не держи в себе. Закидывай, мы слушаем. 🎧\n\n"
            "____________________________________________________________________\n\n"
            "🎵 Welcome to the official unlimitedblades music label bot 🎵\n\n"
            "Here you'll find everything you need: demo submission, feedback, and much more.\n\n"
            "📌 Use the commands below to quickly find what you need: demo submission, feedback, and much more.\n\n"
            "If you've got sound - don't keep it to yourself. Send it, we're listening\n\n"
            "🔹 /senddemo — send demo\n"
            "🔹 /feedback — contact us",
            reply_markup=reply_markup
        )
    elif '_' in query.data:  # Для админских кнопок принять/отклонить
        if query.message.chat.id != ADMIN_CHAT_ID:
            return
        action, user_id = query.data.split('_')
    
    if action == "accept":
        await query.edit_message_caption(
            caption=f"{query.message.caption}\n\n✅ Демка принята!",
            reply_markup=None
        )
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text="🎉 Поздравляем! Ваша демка была принята!"
            )
        except:
            print(f"Не удалось отправить сообщение пользователю {user_id}")
    
    elif action == "reject":
        await query.edit_message_caption(
            caption=f"{query.message.caption}\n\n❌ Демка отклонена",
            reply_markup=None
        )
        try:
            await context.bot.send_message(
                chat_id=user_id,
                text="К сожалению, ваша демка была отклонена. Попробуйте отправить другой трек! 🎵"
            )
        except:
            print(f"Не удалось отправить сообщение пользователю {user_id}")

if __name__ == '__main__':
    from keep_alive import keep_alive
    keep_alive()
    
    application = ApplicationBuilder().token(BOT_TOKEN).build()
    
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("senddemo", send_demo_instruction))
    application.add_handler(MessageHandler(filters.ATTACHMENT, handle_demo))  # Исправлено для работы со всеми типами файлов
    application.add_handler(CallbackQueryHandler(button_callback))
    application.add_handler(CommandHandler("feedback", lambda update, context: update.message.reply_text("📩 Для связи с поддержкой пишите: @unlimitedbladees\n\n📩 For support, please contact: @unlimitedbladees")))

    application.run_polling()
